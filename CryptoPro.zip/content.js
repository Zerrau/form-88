//порт для канала в background.js
var g_bg_port = null; 
var g_return_window = null;
var LOG_LEVEL_DEBUG = 4;
var LOG_LEVEL_INFO = 2;
var LOG_LEVEL_ERROR = 1;
var current_log_level = LOG_LEVEL_ERROR;
var EnableInternalCSP;
//generate random tabid
function gen_tabid () {
  function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
               .toString(16)
               .substring(1);
  }
  return function() {
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
           s4() + '-' + s4() + s4() + s4();
  };
};
var g_tabid = gen_tabid()();
function cpcsp_console_log(level, msg){
        if (level <= current_log_level){
            if (level == LOG_LEVEL_DEBUG)
                console.log("DEBUG: %s", msg);
            if (level == LOG_LEVEL_INFO)
                console.info("INFO: %s", msg);
            if (level == LOG_LEVEL_ERROR)
                console.error("ERROR: %s", msg);
            return;
        }
}

function set_log_level(level){
    current_log_level = level;
    if (current_log_level == LOG_LEVEL_DEBUG)
        cpcsp_console_log(LOG_LEVEL_INFO, "content.js: log_level = DEBUG");
    if (current_log_level == LOG_LEVEL_INFO)
        cpcsp_console_log(LOG_LEVEL_INFO, "content.js: log_level = INFO");
    if (current_log_level == LOG_LEVEL_ERROR)
        cpcsp_console_log(LOG_LEVEL_INFO, "content.js: log_level = ERROR");
}

var isFireFox = navigator.userAgent.match(/Firefox/i);
var isEdge = navigator.userAgent.match(/Edge/i);
if(!isFireFox && !isEdge){
    browserInstance = chrome;
}else {
    browserInstance = browser;
}

// Установить флаг использования mini-csp
window.addEventListener("message", function(event) {
    if (event.source != window)
        return;
    if(event.data == "EnableInternalCSP=true")
    {
        EnableInternalCSP = true;
        cpcsp_console_log(LOG_LEVEL_INFO, "content.js: EnableInternalCSP=true");
        return;
    } else if(event.data == "EnableInternalCSP=false")
    {
        EnableInternalCSP = false;
        cpcsp_console_log(LOG_LEVEL_INFO, "content.js: EnableInternalCSP=false");
        return;
    }
}, false);

function connect(tabid){
    g_bg_port =  browserInstance.runtime.connect({name: g_tabid});
    g_bg_port.onMessage.addListener(function(msg, sender) {
        if(msg.data.type == "result" || msg.data.type == "error") {
            cpcsp_console_log(LOG_LEVEL_DEBUG, "content.js: Sent message to nmcades_plugin:" + JSON.stringify(msg));
            g_return_window.postMessage( msg, "*");
            return;
        }
        if(msg.data.type == "callback") {
            var result;
            if(msg.data.value == "result = window.document.URL"){
                result = window.document.URL;
            } else if(msg.data.value == "result = cadesplugin.EnableInternalCSP"){
                if (typeof EnableInternalCSP === "undefined") {
                    result = false;
                } else result = EnableInternalCSP;
            } else {
                result = "Internal error on content.js callback call";
                cpcsp_console_log(LOG_LEVEL_ERROR, "content.js: Internal error on content.js callback call " + JSON.stringify(msg.data.value));
            }
            msg.data.type = "result";
            args = new Array();
            arg = {type: typeof result, value: result};
            args.push(arg);
            msg.data.params = args;
            cpcsp_console_log(LOG_LEVEL_DEBUG, "content.js: Sent message to background:" + JSON.stringify(msg));
            g_bg_port.postMessage(msg);
        }
    });
    g_bg_port.onDisconnect.addListener(function() {
        g_bg_port = null;
    });
}

//Установить уровень логов
window.addEventListener("message", function(event) {
    if (event.source != window)
        return;
    if(event.data == "set_log_level=debug")
    {
        set_log_level(LOG_LEVEL_DEBUG);
        browserInstance.runtime.sendMessage("set_log_level=debug");
        return;
    } else if(event.data == "set_log_level=info")
    {
        set_log_level(LOG_LEVEL_INFO);
        browserInstance.runtime.sendMessage("set_log_level=info");
        return;
    } else if(event.data == "set_log_level=error")
    {
        set_log_level(LOG_LEVEL_ERROR);
        browserInstance.runtime.sendMessage("set_log_level=error");
        return;
    }
}, false);

window.addEventListener("message", function(event) {
    if (event.source != window)
        return;
    if(event.data == "cadesplugin_echo_request")
    {
        var answer = "cadesplugin_loaded";
        if(isFireFox || isEdge) {
            answer+= "url:";
            answer+= browser.extension.getURL("nmcades_plugin_api.js");
        }
        window.postMessage(answer, "*");
        return;
    }
    if(typeof (event.data.destination) == "undefined" || event.data.destination != "nmcades"){
        return;
    }
    g_return_window = event.source;
    try {
        if(!g_bg_port)
            connect(g_tabid);
        g_bg_port.postMessage({tabid: g_tabid, data: event.data});
    } catch (e){
        cpcsp_console_log("Error connect to extension when sending request")
        window.postMessage({tabid: g_tabid, data:{ type: "error", requestid: event.data.requestid, message:"Lost connection to extension"}}, "*");
    }    
    cpcsp_console_log(LOG_LEVEL_DEBUG, "content.js: Sent message to background:" + JSON.stringify({tabid: g_tabid, data: event.data}));
}, false);

var answer = "cadesplugin_loaded";
if(isFireFox || isEdge) {
    answer+= "url:";
    answer+= browser.extension.getURL("nmcades_plugin_api.js");
}
window.postMessage(answer, "*");
window.postMessage("EnableInternalCSP_request", "*");

cpcsp_console_log(LOG_LEVEL_INFO, "content.js: Cadesplugin loaded");
